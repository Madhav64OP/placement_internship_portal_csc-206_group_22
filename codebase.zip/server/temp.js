import mongoose from 'mongoose';
import dotenv from 'dotenv';
import Company from './models/Company.js'; // Ensure the path and .js extension are correct

dotenv.config();

const seedCompanies = async () => {
    try {
        await mongoose.connect(process.env.MONGO_URI);
        console.log('MongoDB Connected for Seeding Companies...');

        // Optional: Uncomment the next line if you want to clear old dummy companies first
        // await Company.deleteMany(); 
        // console.log('Cleared existing companies.');

        // Calculate some dynamic dates relative to today
        const today = new Date();
        const nextWeek = new Date(today);
        nextWeek.setDate(today.getDate() + 7);
        const nextMonth = new Date(today);
        nextMonth.setDate(today.getDate() + 30);
        const lastWeek = new Date(today);
        lastWeek.setDate(today.getDate() - 7);

        const dummyCompanies = [
            {
                companyName: "Amazon",
                role: "SDE 1",
                season: "Intern",
                jobDescription: "Work on AWS core services, scalable systems, and cloud infrastructure.",
                stipend: "1.1 Lakhs/month",
                location: ["Bangalore", "Hyderabad"],
                deadline: nextWeek,
                criteria: {
                    minCGPA: 8.5,
                    eligibleBranches: ["CSE", "EE", "ECE", "ME", "CH", "PI", "MT", "CE", "BE", "GT", "GPT"],
                    eligibleYears: ["3rd Year"]
                },
                process: ["PPT", "OA", "Interviews"],
                currentStage: "Upcoming" 
            },
            {
                companyName: "Uber",
                role: "Frontend Developer",
                season: "Placement",
                jobDescription: "Develop highly responsive React applications for Uber Eats and core mobility platforms.",
                stipend: "33 LPA",
                location: ["Bangalore"],
                deadline: lastWeek, 
                criteria: {
                    minCGPA: 7.0,
                    eligibleBranches: ["ALL"],
                    eligibleYears: ["4th Year"]
                },
                process: ["OA", "Interview"],
                currentStage: "Completed" 
            },
            {
                companyName: "Jane Street",
                role: "Quantitative Researcher",
                season: "Intern",
                jobDescription: "Build trading algorithms and statistical models using mathematical analysis.",
                stipend: "3.5 Lakhs/month",
                location: ["Mumbai", "Hong Kong"],
                deadline: nextWeek,
                criteria: {
                    minCGPA: 9.0,
                    eligibleBranches: ["CSE", "MNC"],
                    eligibleYears: ["3rd Year", "4th Year"]
                },
                process: ["PPT", "Interviews"],
                currentStage: "PPT" 
            },
            {
                companyName: "Schlumberger",
                role: "Petroleum Engineer",
                season: "Intern",
                jobDescription: "Common activities including exploration, drill planning, and advanced extraction techniques.",
                stipend: "1.0 Lakhs/month",
                location: ["Pune", "Mumbai"],
                deadline: lastWeek, 
                criteria: {
                    minCGPA: 7.0,
                    eligibleBranches: ["GT", "GPT", "ME", "CH"],
                    eligibleYears: ["3rd Year", "4th Year"]
                },
                process: ["OA", "Technical Interview"],
                currentStage: "Completed" 
            },
            {
                companyName: "Texas Instruments",
                role: "Analog Hardware Engineer",
                season: "Intern",
                jobDescription: "Design, simulate, and test complex analog and mixed-signal circuits.",
                stipend: "80,000/month",
                location: ["Bangalore"],
                deadline: nextMonth,
                criteria: {
                    minCGPA: 8.0,
                    eligibleBranches: ["EE", "ECE"],
                    eligibleYears: ["3rd Year"]
                },
                process: ["OA", "Interview"],
                currentStage: "OA" 
            },
            {
                companyName: "McKinsey & Company",
                role: "Business Analyst",
                season: "Placement",
                jobDescription: "Solve complex business challenges, optimize operations, and advise global executives.",
                stipend: "22 LPA",
                location: ["Gurgaon", "Mumbai"],
                deadline: nextWeek,
                criteria: {
                    minCGPA: 7.5,
                    eligibleBranches: ["CSE", "EE", "ECE","ME","CH","PI","MT","CE","BE", "GT", "GPT", "MNC"], // Open to all
                    eligibleYears: ["4th Year", "5th Year"]
                },
                process: ["Resume Shortlist", "Buddy Case Prep", "Case Interviews"],
                currentStage: "PPT" 
            },
            {
                companyName: "ITC Limited",
                role: "Supply Chain Executive",
                season: "Placement",
                jobDescription: "Manage end-to-end FMCG supply chain, logistics optimization, and factory operations.",
                stipend: "16 LPA",
                location: ["Kolkata", "Haridwar"],
                deadline: nextWeek,
                criteria: {
                    minCGPA: 7.0,
                    eligibleBranches: ["ME", "CH", "PI", "CE"],
                    eligibleYears: ["4th Year"]
                },
                process: ["OA", "Group Discussion", "Interview"],
                currentStage: "Interview" 
            },
            {
                companyName: "ISRO",
                role: "Scientist/Engineer 'SC'",
                season: "Placement",
                jobDescription: "Research and development in space technology, satellite launch vehicles, remote sensing and payloads.",
                stipend: "Level 10 Pay Matrix (~12 LPA)",
                location: ["Bangalore", "Trivandrum", "Sriharikota"],
                deadline: nextMonth,
                criteria: {
                    minCGPA: 6.5,
                    eligibleBranches: ["ME", "EE", "ECE", "CSE", "MT","GT","GPT"],
                    eligibleYears: ["4th Year"]
                },
                process: ["Written Test", "Technical Interview"],
                currentStage: "Upcoming" 
            }
        ];

        const savedCompanies = await Company.insertMany(dummyCompanies);
        console.log(`Successfully seeded ${savedCompanies.length} companies!`);

        process.exit();
    } catch (error) {
        console.error(`Error: ${error.message}`);
        process.exit(1);
    }
};

seedCompanies();