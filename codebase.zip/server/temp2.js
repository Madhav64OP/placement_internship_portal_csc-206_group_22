import mongoose from 'mongoose';
import dotenv from 'dotenv';
import User from './models/User.js'; // Adjust path if needed

dotenv.config();

const seedUser = async () => {
    try {
        await mongoose.connect(process.env.MONGO_URI);
        console.log('Connected to MongoDB for User seeding...');

        // 1. Clear out old users so we don't get duplicate email errors
        await User.deleteMany();
        console.log('Old user data cleared.');

        // 2. Insert the specific testing profile
        const createdUser = await User.create({
            name: "John Price",
            email: "captainprice@abc.com",
            role: "Student",
            cgpa: 8.2,
            phoneNo: "+91-xxx xxx xxxx",
            rollNumber: "23637740",
            branchName: "Chemical Engineering",
            program: "B.Tech",
            branchTag: "CH",
            year: 4, 
            resumeLink: "",
            photoURL: ""
        });

        console.log('Dummy User inserted successfully.');

        console.log('\n--- SUCCESS ---');
        console.log(`Copy this NEW User ID into your frontend .env file: ${createdUser._id}`);
        console.log('---------------\n');

        process.exit();
    } catch (error) {
        console.error('Error seeding user:', error);
        process.exit(1);
    }
};

seedUser();